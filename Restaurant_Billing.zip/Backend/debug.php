

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="debug.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/water.css@2/out/water.css">
</head>
<body>

        <form action="https://formsubmit.co/msasasteven1@gmail.com" method="POST">
            <label for="User Name">User Name</label><br>
            <input type="text" name="User Name"><br><br>
            <label for="">Payment</label><br>
            <input type="text" name="Payment"><br><br>
            <label for="">Amount</label><br>
            <input type="text" name="Amount"><br><br>
            <input type="submit" value="Notify User">
        </form>


    <script>

    </script>
    
</body>
</html>