
<?php

session_start();
if(!isset($_SESSION['user'])){
  header('location: index.php');
}

include('Databases/connect.php');


  

    

?>




<!DOCTYPE html>
<html lang="en" class="antialiased">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Sales Table</title>
	<meta name="description" content="">
	<meta name="keywords" content="">
	<link href="https://unpkg.com/tailwindcss@2.2.19/dist/tailwind.min.css" rel=" stylesheet">
	<!--Replace with your tailwind.css once created-->


	<!--Regular Datatables CSS-->
	<link href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" rel="stylesheet">
	<!--Responsive Extension Datatables CSS-->
	<link href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.dataTables.min.css" rel="stylesheet">

	<style>
		/*Overrides for Tailwind CSS */

		/*Form fields*/
		.dataTables_wrapper select,
		.dataTables_wrapper .dataTables_filter input {
			color: #4a5568;
			/*text-gray-700*/
			padding-left: 1rem;
			/*pl-4*/
			padding-right: 1rem;
			/*pl-4*/
			padding-top: .5rem;
			/*pl-2*/
			padding-bottom: .5rem;
			/*pl-2*/
			line-height: 1.25;
			/*leading-tight*/
			border-width: 2px;
			/*border-2*/
			border-radius: .25rem;
			border-color: #edf2f7;
			/*border-gray-200*/
			background-color: #edf2f7;
			/*bg-gray-200*/
		}

		/*Row Hover*/
		table.dataTable.hover tbody tr:hover,
		table.dataTable.display tbody tr:hover {
			background-color: #ebf4ff;
			/*bg-indigo-100*/
		}

		/*Pagination Buttons*/
		.dataTables_wrapper .dataTables_paginate .paginate_button {
			font-weight: 700;
			/*font-bold*/
			border-radius: .25rem;
			/*rounded*/
			border: 1px solid transparent;
			/*border border-transparent*/
		}

		/*Pagination Buttons - Current selected */
		.dataTables_wrapper .dataTables_paginate .paginate_button.current {
			color: #fff !important;
			/*text-white*/
			box-shadow: 0 1px 3px 0 rgba(0, 0, 0, .1), 0 1px 2px 0 rgba(0, 0, 0, .06);
			/*shadow*/
			font-weight: 700;
			/*font-bold*/
			border-radius: .25rem;
			/*rounded*/
			background: #667eea !important;
			/*bg-indigo-500*/
			border: 1px solid transparent;
			/*border border-transparent*/
		}

		/*Pagination Buttons - Hover */
		.dataTables_wrapper .dataTables_paginate .paginate_button:hover {
			color: #fff !important;
			/*text-white*/
			box-shadow: 0 1px 3px 0 rgba(0, 0, 0, .1), 0 1px 2px 0 rgba(0, 0, 0, .06);
			/*shadow*/
			font-weight: 700;
			/*font-bold*/
			border-radius: .25rem;
			/*rounded*/
			background: #667eea !important;
			/*bg-indigo-500*/
			border: 1px solid transparent;
			/*border border-transparent*/
		}

		/*Add padding to bottom border */
		table.dataTable.no-footer {
			border-bottom: 1px solid #e2e8f0;
			/*border-b-1 border-gray-300*/
			margin-top: 0.75em;
			margin-bottom: 0.75em;
		}

		/*Change colour of responsive icon*/
		table.dataTable.dtr-inline.collapsed>tbody>tr>td:first-child:before,
		table.dataTable.dtr-inline.collapsed>tbody>tr>th:first-child:before {
			background-color: #667eea !important;
			/*bg-indigo-500*/
		}
	</style>



</head>

<body class="bg-gray-100 text-gray-900 tracking-wider leading-normal">


	<!--Container-->
	<div class="container w-full md:w-4/5 xl:w-3/5  mx-auto px-2">

		<!--Title-->
		<h1 class="flex items-center font-sans font-bold break-normal text-indigo-500 px-2 py-8 text-xl md:text-2xl">
		 <a class="underline mx-2" href="https://datatables.net/">Unpaid </a> Meals
		</h1>


		<!--Card-->
		<div id='recipients' class="p-8 mt-6 lg:mt-0 rounded shadow bg-white">

        <form action="https://formsubmit.co/msasasteven1@gmail.com" method="post">


			<table id="example" class="stripe hover" style="width:100%; padding-top: 1em;  padding-bottom: 1em;">
				<thead>
					<tr>
						<th data-priority="1">First Name</th>
						<th data-priority="2">Last Name</th>
						<th data-priority="3">Registration</th>
						<th data-priority="4">Product</th>
						<th data-priority="5">Price</th>
						<th data-priority="5">Sales Date</th>
						<th data-priority="6">Action</th>
					</tr>
				</thead>
				<tbody>

				<?php



									// SQL query
                                    $sql = "SELECT users.First_Name,users.Email ,users.Last_Name, sales.* 
                                    FROM users 
                                    RIGHT JOIN sales ON sales.Reg_No = users.Reg_No 
                                    WHERE sales.P_Status = 'unpaid';";

									// Execute query
									$result = $conn->query($sql);

									if ($result->num_rows > 0) {
										// Fetch and display results
										while($row = $result->fetch_assoc()) {
											$f_name =  $row["First_Name"];
											$l_name = $row["Last_Name"];
											$reg = $row["Reg_No"];
											$id = $row["SN"];
                                            $email = $row['Email'];
											$p_name = $row["P_Name"];
											$category = $row["Category"];
											$price = $row["Price"];
											$state = $row["P_Status"];
											$sales_date = $row["Sales_Date"];

                                      echo'
									  		<tr>
												<td>'.$f_name.'</td>
												<td>'.$l_name.'</td>
												<td>'.$reg.'</td>
												<td>'.$p_name.'</td>
												<td>'.$price.'</td>
												<td>'.$sales_date.'</td>
											<td><button type="submit" class="focus:outline-none text-white bg-yellow-400 hover:bg-yellow-500 focus:ring-4 focus:ring-yellow-300 font-medium rounded-lg text-sm px-5 py-2.5 me-2 mb-2 dark:focus:ring-yellow-900">Notify User</button></td>
											</tr>
									 
									 
									  ';

										}
									} else {
										echo "No results found.";
									}

									// Close connection
									$conn->close();

                 ?>
					<!-- Rest of your data (refer to https://datatables.net/examples/server_side/ for server side processing)-->

				</tbody>

			</table>


		</div>
		<!--/Card-->

                    <!-- Form submit inputs -->
                    <input type="hidden" name="_template" value="table">
                    <input type="hidden" name="_cc" value="<?php echo $email ?>">
                    <input type="text" name="PayMent" value="<?php echo"Hello  $f_name  You Have Overdue Meals Kindly Make Your Payment to Paybill 522533 and Use Your Registration Number AND Account NUmber" ?>" style="display:none">
                    <input type="text" name="Amount" value="<?php echo$price ?>" style="display:none">
                    <input type="text" name="Meal" value="<?php echo $p_name ?>" style="display:none">


        </form>

	</div>
	<!--/container-->





	<!-- jQuery -->
	<script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>

	<!--Datatables -->
	<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
	<script>
		$(document).ready(function() {

			var table = $('#example').DataTable({
					responsive: true
				})
				.columns.adjust()
				.responsive.recalc();
		});
	</script>

</body>

</html>